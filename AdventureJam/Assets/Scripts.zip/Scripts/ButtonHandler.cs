﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ButtonHandler : MonoBehaviour
{

    private DisplayImage currentDisplay;

    void Start()
    {//inicialmente, a variável irá buscar o GO e pegar o script que está atrelado à ela, para poder executar 
     //o CurrentWall e alterar as telas da Escape Room

        currentDisplay = GameObject.Find("displayImage").GetComponent<DisplayImage>();
    }

    public void OnRightClickArrow()//botão direito pressionado
    {
        currentDisplay.CurrentWall = currentDisplay.CurrentWall + 1;
    }

    public void OnLeftClickArrow() //botão esquerdo pressionado
    {
        currentDisplay.CurrentWall = currentDisplay.CurrentWall - 1;
    }
}
