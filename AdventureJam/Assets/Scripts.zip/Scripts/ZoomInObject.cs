﻿using UnityEngine;
using System.Collections;
using System;

public class ZoomInObject : MonoBehaviour, IInterectable
{//código utilizado para dar zoom em um objeto que for interagível
    public float ZoomRatio = 0.5f;

    //o método abaixo é executado a partir do código Interact. Quando ele é chamado, aplica zoom no objeto
    public void Interact(DisplayImage currentDisplay)
    {
        //calcula o tamanho da amplitude câmera;
        Camera.main.orthographicSize *= ZoomRatio;

        //aplica o zoom, com base no GO que foi clicado pelo usuário.
        Camera.main.transform.position = new Vector3(this.transform.position.x, this.transform.position.y,
            Camera.main.transform.position.z);
    }
}
